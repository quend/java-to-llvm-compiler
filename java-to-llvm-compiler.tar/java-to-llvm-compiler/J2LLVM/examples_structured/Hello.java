public class Hello{
    public void main(){

	printf("Hello world\n");
    }
}
